/*
 * $XTermId: version.h,v 1.71 2026/09/07 14:28:00 tom Exp $
 *
 * https://invisible-island.net/luit/
 */
#define LUIT_VERSION "2.0-20260907"
