/* $Id: patchlev.h,v 1.100 2024/10/31 07:45:36 tom Exp $ */
#define RELEASE 2
#define PATCHLEVEL 7
#define PATCH_DATE 20241031
