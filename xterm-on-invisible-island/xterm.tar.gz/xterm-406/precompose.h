/* $XFree86: xc/programs/xterm/precompose.h,v 1.1 2000/08/26 04:33:54 dawes Exp $ */

#ifndef PRECOMPOSE_H
#define PRECOMPOSE_H

int do_precomposition(int base, int comb);

/* returns unicode value if a canonical composition exists,
   otherwise -1 */

#endif
