/*
 * $XTermId: version.h,v 1.69 2025/09/12 07:49:50 tom Exp $
 *
 * https://invisible-island.net/luit/
 */
#define LUIT_VERSION "2.0-20250912"
