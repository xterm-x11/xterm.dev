/* $Id: patchlev.h,v 1.103 2024/12/05 00:30:03 tom Exp $ */
#define RELEASE 2
#define PATCHLEVEL 7
#define PATCH_DATE 20241204
