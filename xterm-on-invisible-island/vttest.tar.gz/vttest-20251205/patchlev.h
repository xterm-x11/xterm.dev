/* $Id: patchlev.h,v 1.107 2025/12/05 20:46:35 tom Exp $ */
#define RELEASE 2
#define PATCHLEVEL 7
#define PATCH_DATE 20251205
