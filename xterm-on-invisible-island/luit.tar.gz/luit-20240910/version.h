/*
 * $XTermId: version.h,v 1.68 2024/09/09 21:14:24 tom Exp $
 *
 * https://invisible-island.net/luit/
 */
#define LUIT_VERSION "2.0-20240910"
